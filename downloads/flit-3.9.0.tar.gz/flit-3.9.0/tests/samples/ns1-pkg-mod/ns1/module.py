"""An example single file module in a namespace package
"""

__version__ = '0.1'

