"""
Docstring formatted like this.
"""

__version__ = '7.0'
