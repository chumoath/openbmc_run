"""
A module with a local version specifier
"""

__version__ = "0.1.dev0+test"
