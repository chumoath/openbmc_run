#!/usr/bin/env python

import sys

from Cython.Debugger import Cygdb as cygdb

if __name__ == '__main__':
    cygdb.main()
