from trove_classifiers import sorted_classifiers

for classifier in sorted_classifiers:
    print(classifier)
