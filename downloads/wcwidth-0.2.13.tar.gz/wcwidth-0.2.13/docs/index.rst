wcwidth
=======

.. toctree::

   intro
   unicode_version
   specs
   api

Indices and tables
------------------

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
