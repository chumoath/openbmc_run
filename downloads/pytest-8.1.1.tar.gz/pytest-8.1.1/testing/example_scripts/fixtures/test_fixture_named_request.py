# mypy: allow-untyped-defs
import pytest


@pytest.fixture
def request():
    pass


def test():
    pass
