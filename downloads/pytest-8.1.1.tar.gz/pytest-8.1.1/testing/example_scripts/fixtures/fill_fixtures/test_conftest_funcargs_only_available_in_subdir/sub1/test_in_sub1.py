# mypy: allow-untyped-defs
def test_1(arg1):
    pass
