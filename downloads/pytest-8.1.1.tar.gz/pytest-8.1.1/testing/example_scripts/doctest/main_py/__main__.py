# mypy: allow-untyped-defs
def test_this_is_ignored():
    assert True
