# mypy: allow-untyped-defs
# content of test_second.py
def test_2():
    pass
