# mypy: allow-untyped-defs
def test_mocker(mocker):
    mocker.MagicMock()
