# content of test_third.py
def test_3():
    pass
