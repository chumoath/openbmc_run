collect_ignore = ["nonpython", "customdirectory"]
