pytest-8.0.1
=======================================

pytest 8.0.1 has just been released to PyPI.

This is a bug-fix release, being a drop-in replacement. To upgrade::

  pip install --upgrade pytest

The full changelog is available at https://docs.pytest.org/en/stable/changelog.html.

Thanks to all of the contributors to this release:

* Bruno Oliveira
* Clément Robert
* Pierre Sassoulas
* Ran Benita


Happy testing,
The pytest Development Team
