class Foo { };
typedef int Integer;
