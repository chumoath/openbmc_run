var typemap_out_optimal = require("typemap_out_optimal");

typemap_out_optimal.XX.trace = false;
x = typemap_out_optimal.XX.create();
x = typemap_out_optimal.XX.createConst();
