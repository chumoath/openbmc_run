var struct_rename = require("struct_rename");

b = new struct_rename.Bar();
