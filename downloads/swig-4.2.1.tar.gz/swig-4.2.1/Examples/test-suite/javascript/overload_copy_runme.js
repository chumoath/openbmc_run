var overload_copy = require("overload_copy");

f = new overload_copy.Foo();
g = new overload_copy.Foo(f);
