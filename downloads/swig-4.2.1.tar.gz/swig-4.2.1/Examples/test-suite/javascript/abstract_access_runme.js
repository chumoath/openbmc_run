var abstract_access = require("abstract_access");

var d = new abstract_access.D()
if (d.do_x() != 1) {
   throw "Error";
}
