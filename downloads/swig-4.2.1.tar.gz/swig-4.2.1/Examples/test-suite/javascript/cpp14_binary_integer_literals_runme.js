var cpp14_binary_integer_literals = require("cpp14_binary_integer_literals");

if (cpp14_binary_integer_literals.b1 != 1) {
    throw new Error;
}

if (cpp14_binary_integer_literals.b2 != 2) {
    throw new Error;
}

if (cpp14_binary_integer_literals.b3 != 3) {
    throw new Error;
}

if (cpp14_binary_integer_literals.b4 != 4) {
    throw new Error;
}

if (cpp14_binary_integer_literals.b5 != 5) {
    throw new Error;
}

if (cpp14_binary_integer_literals.b6 != 6) {
    throw new Error;
}

if (cpp14_binary_integer_literals.b7 != 7) {
    throw new Error;
}

if (cpp14_binary_integer_literals.b8 != 8) {
    throw new Error;
}
