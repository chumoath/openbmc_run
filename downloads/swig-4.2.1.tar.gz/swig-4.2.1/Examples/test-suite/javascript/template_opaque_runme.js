var template_opaque = require("template_opaque");

v = new template_opaque.OpaqueVectorType(10);

template_opaque.FillVector(v);
