var abstract_virtual = require("abstract_virtual");

d = new abstract_virtual.D()

if (d == undefined)
  throw "Error";

e = new abstract_virtual.E()

if (e == undefined)
  throw "Error";
