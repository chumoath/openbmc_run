var cpp17_hex_floating_literals = require("cpp17_hex_floating_literals");

if (cpp17_hex_floating_literals.f1 != 0.) {
    throw new Error;
}

if (cpp17_hex_floating_literals.f2 != 0.) {
    throw new Error;
}

if (cpp17_hex_floating_literals.f3 != 0.) {
    throw new Error;
}

if (cpp17_hex_floating_literals.f4 != 7.5) {
    throw new Error;
}

if (cpp17_hex_floating_literals.f5 != 20.) {
    throw new Error;
}

if (cpp17_hex_floating_literals.f6 != 64.) {
    throw new Error;
}

if (cpp17_hex_floating_literals.f7 != 11452.) {
    throw new Error;
}

if (cpp17_hex_floating_literals.f8 != 149140.) {
    throw new Error;
}

if (cpp17_hex_floating_literals.f9 != 18253638.) {
    throw new Error;
}
