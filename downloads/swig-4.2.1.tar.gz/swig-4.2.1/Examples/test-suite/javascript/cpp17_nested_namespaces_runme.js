var cpp17_nested_namespaces = require("cpp17_nested_namespaces");

new cpp17_nested_namespaces.A1Struct().A1Method()
new cpp17_nested_namespaces.B1Struct().B1Method()
new cpp17_nested_namespaces.C1Struct().C1Method()
new cpp17_nested_namespaces.createA1Struct().A1Method()
new cpp17_nested_namespaces.createB1Struct().B1Method()
new cpp17_nested_namespaces.createC1Struct().C1Method()

new cpp17_nested_namespaces.B2Struct().B2Method()
new cpp17_nested_namespaces.C2Struct().C2Method()
new cpp17_nested_namespaces.createB2Struct().B2Method()
new cpp17_nested_namespaces.createC2Struct().C2Method()

new cpp17_nested_namespaces.B3Struct().B3Method()
new cpp17_nested_namespaces.C3Struct().C3Method()
new cpp17_nested_namespaces.createB3Struct().B3Method()
new cpp17_nested_namespaces.createC3Struct().C3Method()
