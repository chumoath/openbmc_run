package main

import "swigtests/keyword_rename"

func main() {
	keyword_rename.Xgo(1)
	keyword_rename.Xchan(1)
}
