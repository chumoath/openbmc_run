package main

import "swigtests/sneaky1"

func main() {
	_ = sneaky1.Add(3, 4)
	_ = sneaky1.Subtract(3, 4)
	_ = sneaky1.Mul(3, 4)
	_ = sneaky1.Divide(3, 4)
}
