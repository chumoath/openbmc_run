### Issue reference
<!-- If you're adding a new feature, please make an issue first -->
<!-- If you're fixing a trivial bug (e.g. a typo) you need not make an issue first -->
<!-- If you're fixing a non-trivial bug, please go ahead and make an issue first -->
<!-- Not all proposals for new functionality will be accepted, so please save yourself some work by checking first with an issue -->
more-itertools/more-itertools#XXXX

### Changes
<!-- Describe what your PR adds, fixes, or changes here -->

### Checks and tests
<!-- Please run `make all-checks` to help make sure your branch meets the standards enforced by GitHub Actions. -->
