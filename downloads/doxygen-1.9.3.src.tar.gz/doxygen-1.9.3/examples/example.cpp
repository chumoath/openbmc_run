/** A Example_Test class.
 *  More details about this class.
 */

class Example_Test
{
  public:
    /** An example member function.
     *  More details about this function.
     */
    void example();
};

void Example_Test::example() {}

/** \example example_test.cpp
 * This is an example of how to use the Example_Test class.
 * More details about this example.
 */
